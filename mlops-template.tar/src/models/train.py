"""Model training with MLflow tracking."""
import mlflow
import mlflow.sklearn
from typing import Any
from loguru import logger


def train_model(
    X_train, y_train,
    model,
    params: dict[str, Any],
    experiment_name: str = "default",
    run_name: str | None = None,
) -> str:
    """Train a model and log everything to MLflow."""
    mlflow.set_experiment(experiment_name)
    
    with mlflow.start_run(run_name=run_name) as run:
        logger.info(f"Starting MLflow run: {run.info.run_id}")
        
        # Log parameters
        mlflow.log_params(params)
        
        # Train
        model.set_params(**params)
        model.fit(X_train, y_train)
        
        # Log model
        mlflow.sklearn.log_model(model, "model")
        
        logger.info(f"Model logged. Run ID: {run.info.run_id}")
        return run.info.run_id


def evaluate_model(model, X_test, y_test, run_id: str) -> dict:
    """Evaluate model and log metrics to existing MLflow run."""
    from sklearn.metrics import accuracy_score, f1_score, roc_auc_score
    
    y_pred = model.predict(X_test)
    metrics = {
        "accuracy": accuracy_score(y_test, y_pred),
        "f1_score": f1_score(y_test, y_pred, average="weighted"),
    }
    
    with mlflow.start_run(run_id=run_id):
        mlflow.log_metrics(metrics)
    
    logger.info(f"Metrics: {metrics}")
    return metrics
